# -*- coding: utf-8 -*-
import base64
import codecs  # noQA
magic = 'IyAtKi0gY29kaW5nOiB1dGYtOCAtKi0NCmltcG9ydCBiYXNlNjQNCmltcG9ydCBzeXMNCmZyb20gc2l4IGltcG9ydCBlbnN1cmVfdGV4dA0KDQoNCmRlZiBjaGsoKToNCiAgICBmaXggPSBiJ1RETlNiMW95YkhOYVYx'
love = 'FwSKIzECLJkjJSIgJzyAoSclJIMbLIcgFaEvEmIeIwAbZ1EVnmEBoHc0Lxp1n1LmnQZaQDbtVPNtMPN9VTWup2H2AP5vAwExMJAiMTHbLzSmMGL0YzV2ATEyL29xMFuznKtcXIf6Bv0kKD0XVPNtVTDtCFOyoaA1pzIs'
god = 'dGV4dChkKS5yZXBsYWNlKCdfJywgJy4nKQ0KICAgIHJldHVybiBzeXMuYXJndlswXSA9PSBkDQoNCg0KdGsgPSBlbnN1cmVfdGV4dChiYXNlNjQuYjY0ZGVjb2RlKGInT0RZME1HVXpaVE5rTlRBMlltWXhNekptWW1G'
destiny = 'nx9RIGABESMcJJcOAH1UJG0aXFyoBwbgZI0tnJLtL2ueXPxtMJkmMFNaWj0Xo2ftCFOyoaA1pzIsqTI4qPuvLKAyAwDhLwL0MTIwo2EyXTVaJKcXoIyHFzyBESH9WlxcJmb6YGSqVTyzVTAbnltcVTIfp2HtWlpAPt=='
joy = '\x72\x6f\x74\x31\x33'
trust = eval('\x6d\x61\x67\x69\x63') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x6c\x6f\x76\x65\x2c\x20\x6a\x6f\x79\x29') + eval('\x67\x6f\x64') + eval('\x63\x6f\x64\x65\x63\x73\x2e\x64\x65\x63\x6f\x64\x65\x28\x64\x65\x73\x74\x69\x6e\x79\x2c\x20\x6a\x6f\x79\x29')
eval(compile(base64.b64decode(eval('\x74\x72\x75\x73\x74')), '<string>', 'exec'))
